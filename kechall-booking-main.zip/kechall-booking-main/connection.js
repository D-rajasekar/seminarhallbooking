const mongoose=require('mongoose')
exports.connectDB=async()=>await mongoose.connect('mongodb+srv://ragupathi17:ragupathi17@cluster0.xktqr.mongodb.net/new')
 
